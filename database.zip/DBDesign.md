### 简单食物店 数据库模型

本project中，我们设计的数据库模型如下所示：

![file-page1](/Users/Souler/Downloads/New Pages/file-page1.png)

![file-page2](/Users/Souler/Downloads/New Pages/file-page2.png)

![file-page3](/Users/Souler/Downloads/New Pages/file-page3.png)

![file-page4](/Users/Souler/Downloads/New Pages/file-page4.png)

![file-page5](/Users/Souler/Downloads/New Pages/file-page5.png)

